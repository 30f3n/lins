fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'مثال سكربت محمي بالرخصة'
version '1.0.0'

server_script 'server.lua'
